package com.sw.fd.controller;

public class MenuController {
}
