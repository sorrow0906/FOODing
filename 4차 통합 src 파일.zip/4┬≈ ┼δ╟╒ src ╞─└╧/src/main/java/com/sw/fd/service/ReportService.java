package com.sw.fd.service;

import com.sw.fd.entity.Report;
import com.sw.fd.entity.Review;
import org.springframework.stereotype.Service;

@Service
public class ReportService {

}
